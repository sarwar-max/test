package com.mphasis;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.mphasis.domain.Book;
import com.mphasis.repository.BookRepository;

@SpringBootApplication
public class EBookStoreAppApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(EBookStoreAppApplication.class, args);
	}

	@Autowired
	@Qualifier("bookRepository")
	private BookRepository bookRepository;

	@Override
	public void run(String... args) throws Exception {

		bookRepository.save(new Book(null, "Java", "Apress", "978-1-61729-427-3", 288, 2018));
		bookRepository.save(new Book(null, ".Net", "Apress", "978-1-484221-10-5", 176, 2016));
		bookRepository.save(new Book(null, "C++", "Orelly", "978-1-84968-742-3", 276, 2013));
		bookRepository.save(new Book(null, "Excel", "Microsoft", "978-0-596-00302-9", 320, 2002));
	}
}
