package com.mphasis.service;

import java.util.List;

import com.mphasis.domain.Book;

public interface IBookService {

	Book save(Book book);

	Book update(Book book);

	void delete(int id);

	Book getBookById(int id);

	List<Book> getAllBooks();
	
	List<Book> getByBookTitle(String title);

	List<Book> getByBookPublisherLike(String publisher);
	
	List<Book> getByYear(Integer year);
}
