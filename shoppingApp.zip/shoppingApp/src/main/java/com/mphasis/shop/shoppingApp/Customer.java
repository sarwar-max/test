package com.mphasis.shop.shoppingApp;

import java.util.Iterator;
import java.util.List;

public class Customer  {

	private int custId;
	private String custName;
	
	private List<Address> address;
		
	 
	public List<Address> getAddress() {
		return address;
	}
	public void setAddress(List<Address> address) {
		this.address = address;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
//	@Override
//	public String toString() {
//		return "Customer [custId=" + custId + ", custName=" + custName + "]";
//	}
	 
		 
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", address=" + address + "]";
	}
	public void details() {
		 System.out.println("Customer Details here.....");
		 Iterator iterate=address.iterator();
		 while(iterate.hasNext()) {
			 System.out.println(iterate.next());
		 }
		
	}
	
}
