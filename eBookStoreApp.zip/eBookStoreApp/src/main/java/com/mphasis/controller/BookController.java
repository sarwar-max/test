package com.mphasis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.domain.Book;
import com.mphasis.service.IBookService;

@RestController
@Scope("request")
public class BookController {

	@Autowired
	@Qualifier("bookService")
	private IBookService bookService;

	@GetMapping(value = "/books", produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<Book> getAllBooks(@RequestParam(name =  "book_year", required = false) Integer year) {

		List<Book> books = null;
		if (year == null) {
			books = bookService.getAllBooks();
		} else {
			books = bookService.getByYear(year);
		}
		
		return books;
	}

	@GetMapping(value = "/books/{book_id}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public Book getBookById(@PathVariable("book_id") int id) {

		return bookService.getBookById(id);
	}

	@GetMapping(value = "/books/title/{book_title}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<Book> getByBookTitle(@PathVariable("book_title") String title) {

		return bookService.getByBookTitle(title);
	}

	@GetMapping(value = "/books/publisher/{book_publisher}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<Book> getByBookPublisherLike(@PathVariable("book_publisher") String publisher) {

		return bookService.getByBookPublisherLike(publisher);
	}

	@PostMapping(value = "/books", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ResponseStatus(code = HttpStatus.CREATED)
	public Book addBook(@RequestBody Book book) {

		return bookService.save(book);
	}

	@PutMapping(value = "/books", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	@ResponseStatus(code = HttpStatus.OK)
	public Book updateBook(@RequestBody Book book) {

		return bookService.update(book);
	}

	@DeleteMapping(value = "/books/{book_id}")
	@ResponseStatus(code = HttpStatus.NO_CONTENT)
	public void deleteBookById(@PathVariable("book_id") int id) {

		bookService.delete(id);
	}
}
