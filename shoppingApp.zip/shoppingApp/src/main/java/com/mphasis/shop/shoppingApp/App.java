package com.mphasis.shop.shoppingApp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	public static void main(String[] args) {
		System.out.println("Shopping World!");

		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		
//		 Login log1=(Login)context.getBean("login");
//		 log1.welcomeUser();
//		 System.out.println(log1);
//		 
//		 Customer custObj=(Customer) context.getBean("customer");
//	     System.out.println(custObj);
//	     custObj.details();
		
		Product prodObj=(Product)context.getBean("product");
	    System.out.println(prodObj);
	      
	    Cart cartObj=(Cart)context.getBean("cart");
	    System.out.println(cartObj);

      
	          
	}
}
